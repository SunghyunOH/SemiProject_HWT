package com.kh.freeBoard.model.dao;


import com.kh.freeBoard.model.vo.freeBoard;
import com.kh.member.model.vo.Member;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import static com.kh.common.JDBCTemplate.close;


public class BoardDAO {
	
	private Properties prop;
	
	public BoardDAO() {
		prop = new Properties();
		String filePath = BoardDAO.class
				          .getResource("/config/freeboard-sql.properties").getPath();
		
		try {
			prop.load(new FileReader(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int freeGetListCount(Connection con) {
		int result = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("freelistCount");
		
		try {
			ps = con.prepareStatement(sql);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				result = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			close(rs);
			close(ps);
		}
		
		return result;
	}

	public ArrayList<freeBoard> freeSelectList(Connection con, int currentPage, int limit) {
		ArrayList<freeBoard> list = new ArrayList<>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("freeSelectList");
		
		try {
			ps = con.prepareStatement(sql);
			
			int startRow = (currentPage - 1) * limit + 1;
			int endRow = startRow + limit - 1;
			
			ps.setInt(1, endRow);
			ps.setInt(2, startRow);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				freeBoard b = new freeBoard();
				
				b.setFbNo(rs.getInt("FBNO"));
				b.setFbTitle(rs.getString("FBTITLE"));
				b.setFbContent(rs.getString("FBCONTENT"));
				b.setFbdate(rs.getDate("FBDATE"));
				b.setStatus(rs.getString("STATUS"));
				b.setFcount(rs.getInt("FBCOUNT"));
				b.setFfile(rs.getString("FBFILE"));
				b.setFwriter(rs.getString("FWRITER"));

				list.add(b);
				
			}		
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			close(rs);
			close(ps);
		}
		
		return list;
	}

	public freeBoard freeSelectOne(Connection con, int fbno) {
		freeBoard b = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("freeSelectOne");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setInt(1, fbno);
			
			rs = ps.executeQuery();
			

			
			if( rs.next() ) {
				b = new freeBoard();
				
				b.setFbNo(rs.getInt("FBNO"));
				b.setFbTitle(rs.getString("FBTITLE"));
				b.setFbContent(rs.getString("FBCONTENT"));
				b.setFbdate(rs.getDate("FBDATE"));
				b.setStatus(rs.getString("status"));
				b.setFcount(rs.getInt("FBCOUNT"));
				b.setFfile(rs.getString("FBFILE"));
				b.setFwriter(rs.getString("FWRITER"));
				
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			close(rs);
			close(ps);
		}
		
		return b;
	}

	public int insertFree(Connection con, freeBoard b, Member m) {
		int result = 0;
		PreparedStatement ps = null;
		
		String sql = prop.getProperty("freeInsertBoard");
		
		try {
			ps = con.prepareStatement(sql);

			ps.setString(1, b.getFbTitle());
			ps.setString(2, b.getFbContent());
			ps.setString(3, m.getmNick());
			ps.setString(4, b.getFfile());


			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(ps);
		}
		
		return result;
	}

	public int freeUpdateBoard(Connection con, freeBoard b, Member m) {
		int result = 0;
		PreparedStatement ps = null;
		
		String sql = prop.getProperty("freeUpdateBoard");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setString(1,  b.getFbTitle() );
			ps.setString(2,  b.getFbContent() );
			ps.setString(3, b.getFfile());
			ps.setInt(   4,  b.getFbNo() );



			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
		}
		
		return result;
	}

	public int deleteFree(Connection con, int fbno) {
		int result = 0;
		PreparedStatement ps = null;
		String sql = prop.getProperty("deleteFree");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setInt(1, fbno);

			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(ps);
		}
		
		
		
		return result;
	}


	public int freeUpdateReadCount(Connection con, int fbno) {

		int result = 0;
		PreparedStatement ps = null;

		String sql = prop.getProperty("freeUpdateReadCount");

		try {
			ps = con.prepareStatement(sql);

			ps.setInt(1, fbno);

			result = ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
		}
		return result;
	}

	public int reportPointPlus(Connection con, String nick, int fbno) {

		int result = 0;
		PreparedStatement ps = null;

		String sql = prop.getProperty("FreportPointUp");

		try {
			ps = con.prepareStatement(sql);

			ps.setString(1,nick);
			ps.setInt(2,fbno);

			result = ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
		}
		return result;



	}
}
