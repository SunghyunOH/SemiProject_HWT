package com.kh.freeBoard.model.service;

import com.kh.freeBoard.model.dao.BoardDAO;
import com.kh.freeBoard.model.vo.freeBoard;
import com.kh.member.model.vo.Member;

import java.sql.Connection;
import java.util.ArrayList;

import static com.kh.common.JDBCTemplate.*;


public class BoardService {
	private Connection con;
	private BoardDAO dao = new BoardDAO();

	public int freeGetListCount() {
		con = getConnection();

		int result = dao.freeGetListCount(con);

		close(con);

		return result;
	}

	public ArrayList<freeBoard> freeSelectList(int currentPage, int limit) {
		con = getConnection();
		ArrayList<freeBoard> list = dao.freeSelectList(con, currentPage, limit);

		close(con);

		return list;
	}

	public freeBoard freeSelectOne(int fbno) {
		con = getConnection();
		
		freeBoard b = dao.freeSelectOne(con, fbno);

		if( b != null ) {
			// 조회수 1 증가
			b.setFcount( b.getFcount() + 1);

			int result = dao.freeUpdateReadCount(con, fbno);

			if(result > 0) {
				commit(con);
			} else {
				rollback(con);
			}
		}

		close(con);

		return b;
	}

	public int insertFree(freeBoard b, Member m) {
		
		con = getConnection();
		
		int result = dao.insertFree(con, b, m);
		
		if( result > 0) {
			commit(con);
		} else {
			rollback(con);
		}
		
		close(con);

		return result;
	}

	public freeBoard freeUpdateView(int fbno) {
		con = getConnection();
		
		freeBoard b = dao.freeSelectOne(con, fbno);
		
		close(con);
		
		return b;
	}

	public int freeUpdateBoard(freeBoard b, Member m) {
		con = getConnection();
		int result = dao.freeUpdateBoard(con, b, m);
		
		if( result > 0 ) {
			commit(con);
		} else {
			rollback(con);
		}
		
		close(con);
		
		return result;
	}

	public int deleteFree(int fbno) {
		con = getConnection();
		int result = dao.deleteFree(con, fbno);
		
		if( result > 0) {
			commit(con); 
		}else {
			rollback(con);
		}
		
		close(con);

		return result;
	}


	public int reportPointPlus(String nick, int fbno) {
		con = getConnection();
		int result = dao.reportPointPlus(con, nick, fbno);

		if( result > 0) {
			commit(con);
		}else {
			rollback(con);
		}

		close(con);

		return result;

	}
}
