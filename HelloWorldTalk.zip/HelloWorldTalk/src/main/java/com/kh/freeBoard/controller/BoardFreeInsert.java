package com.kh.freeBoard.controller;

import com.kh.freeBoard.model.service.BoardService;
import com.kh.freeBoard.model.vo.freeBoard;
import com.kh.member.model.vo.Member;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Servlet implementation class BoardNoticeInsert
 */
@WebServlet("/freeInsert.do")
public class BoardFreeInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public BoardFreeInsert() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int maxSize = 1024 * 1024 * 10;

		String root = request.getServletContext().getRealPath("/");
		String savePath = root + "resources/boardUploadFiles";

		MultipartRequest mre = new MultipartRequest(request, savePath, maxSize, "UTF-8",
				new DefaultFileRenamePolicy());



		String title = mre.getParameter("title");
		String content = mre.getParameter("content");
		String file = mre.getFilesystemName("file");



		
		freeBoard b = new freeBoard(title, content, file);
		
		BoardService service = new BoardService();

		HttpSession session = request.getSession(false);


		Member m = (Member) session.getAttribute("member");

		int result = service.insertFree(b,m);
		
		if( result > 0) {
			response.sendRedirect("/hwt/free.do");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
