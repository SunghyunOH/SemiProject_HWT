package com.kh.freeBoard.model.vo;

import java.io.Serializable;
import java.sql.Date;

public class freeBoard implements Serializable{

	private static final long serialVersionUID = 1008L;

	private int fbNo;
	private String fbTitle;
	private String fbContent;
	private Date fbdate;
	private String status;
	private int fcount;
	private String ffile;
	private String fwriter;

	public freeBoard() {
		super();
		// TODO Auto-generated constructor stub
	}

	public freeBoard(String fbTitle, String fbContent, String ffile) {
		this.fbTitle = fbTitle;
		this.fbContent = fbContent;
		this.ffile = ffile;
	}

	public freeBoard(String fbTitle, String fbContent) {
		this.fbTitle = fbTitle;
		this.fbContent = fbContent;
	}

	public freeBoard(int fbNo, String fbTitle, String fbContent, Date fbdate, String status, int fcount,String ffile ,String fwriter) {
		this.fbNo = fbNo;
		this.fbTitle = fbTitle;
		this.fbContent = fbContent;
		this.fbdate = fbdate;
		this.status = status;
		this.fcount = fcount;
		this.ffile=ffile;
		this.fwriter = fwriter;
	}

	public int getFbNo() {
		return fbNo;
	}

	public void setFbNo(int fbNo) {
		this.fbNo = fbNo;
	}

	public String getFbTitle() {
		return fbTitle;
	}

	public void setFbTitle(String fbTitle) {
		this.fbTitle = fbTitle;
	}

	public String getFbContent() {
		return fbContent;
	}

	public void setFbContent(String fbContent) {
		this.fbContent = fbContent;
	}

	public Date getFbdate() {
		return fbdate;
	}

	public void setFbdate(Date fbdate) {
		this.fbdate = fbdate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getFcount() {
		return fcount;
	}

	public void setFcount(int fcount) {
		this.fcount = fcount;
	}

	public String getFfile() {
		return ffile;
	}

	public void setFfile(String ffile) {
		this.ffile = ffile;
	}

	public String getFwriter() {
		return fwriter;
	}

	public void setFwriter(String fwriter) {
		this.fwriter = fwriter;
	}

	@Override
	public String toString() {
		return "freeBoard{" +
				"fbNo=" + fbNo +
				", fbTitle='" + fbTitle + '\'' +
				", fbContent='" + fbContent + '\'' +
				", fbdate=" + fbdate +
				", status='" + status + '\'' +
				", fcount=" + fcount +
				", fwriter='" + fwriter + '\'' +
				'}';
	}
}
