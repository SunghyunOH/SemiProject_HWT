package com.kh.common.report;

import com.kh.educationBoard.model.service.BoardService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/eduReportPoint.do")
public class educationReport extends HttpServlet {

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BoardService service = new BoardService();

        String nick = request.getParameter("nick");
        int ebno = Integer.parseInt(request.getParameter("ebno"));


        int result = service.reportPointPlus(nick, ebno);

        if(result > 0) {
            response.sendRedirect("/hwt/education.do");
        }
    }

}
