package com.kh.common.report;

import com.kh.freeBoard.model.service.BoardService;
import com.kh.freeBoard.model.vo.freeBoard;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/freeReportPoint.do")
public class freeReport extends HttpServlet {

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BoardService service = new BoardService();

        String nick = request.getParameter("nick");
        int fbno = Integer.parseInt(request.getParameter("fbno"));



        int result = service.reportPointPlus(nick, fbno);
        if(result > 0) {
            response.sendRedirect("/hwt/free.do");
        }
    }
}
