package com.kh.admin.model.dao;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.admin.model.vo.AdList;
import com.kh.admin.model.vo.DeList;
import com.kh.admin.model.vo.RpList;
import com.kh.admin.model.vo.UserList;

import static com.kh.common.JDBCTemplate.*;


public class UserListDAO {

	private Properties prop;
	
	public UserListDAO() {
		prop = new Properties();
		
		String filePath = UserListDAO.class.getResource("/config/admin-sql.properties").getPath();
		try {
			prop.load(new FileReader(filePath));
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	public int getListCount(Connection con) {
		int result = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("listCount");
		
		try {
			ps = con.prepareStatement(sql);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				result = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(ps);
		}
		
		
		return result;
	}

	public ArrayList<UserList> selectList(Connection con, int currentPage, int limit) {
		ArrayList<UserList> list = new ArrayList<>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("selectList");
		
		try {
			ps = con.prepareStatement(sql);
			
			int startRow = (currentPage - 1) * limit + 1;
			int endRow = startRow + limit -1;
			
			ps.setInt(1, endRow);
			ps.setInt(2, startRow);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				UserList ul = new UserList();
				
				ul.setMno(rs.getInt("mno"));
				ul.setGradeno(rs.getInt("gradeno"));
				ul.setMuserid(rs.getString("muserid"));
				ul.setMname(rs.getString("mname"));
				ul.setMemail(rs.getString("memail"));
				ul.setMnickname(rs.getString("mnickname"));
			    ul.setMjoin(rs.getDate("mjoin"));
			    ul.setMrevice(rs.getDate("mrevice"));
			    ul.setMdelete(rs.getDate("mdelete"));
			    ul.setMreport(rs.getInt("mreport"));
				ul.setMstatus(rs.getString("mstatus"));

			    
			    list.add(ul);
			
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(ps);
		}

		
		return list;
	}

	public int getAdminListCount(Connection con) {
		int result = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;

		String sql = prop.getProperty("adminlistCount");

		try {
			ps = con.prepareStatement(sql);

			rs = ps.executeQuery();

			if(rs.next()) {
				result = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(ps);
		}


		return result;
	}

	public ArrayList<AdList> adminSelectList(Connection con, int currentPage, int limit) {
		ArrayList<AdList> list = new ArrayList<>();
		PreparedStatement ps = null;
		ResultSet rs = null;

		String sql = prop.getProperty("adminSelectList");

		try {
			ps = con.prepareStatement(sql);

			int startRow = (currentPage - 1) * limit + 1;
			int endRow = startRow + limit -1;

			ps.setInt(1, endRow);
			ps.setInt(2, startRow);

			rs = ps.executeQuery();

			while(rs.next()) {
				AdList al = new AdList();

				al.setMno(rs.getInt("mno"));
				al.setGradeno(rs.getInt("gradeno"));
				al.setMuserid(rs.getString("muserid"));
				al.setMname(rs.getString("mname"));
				al.setMemail(rs.getString("memail"));
				al.setMnickname(rs.getString("mnickname"));
				al.setMjoin(rs.getDate("mjoin"));
				al.setMrevice(rs.getDate("mrevice"));
				al.setMdelete(rs.getDate("mdelete"));
				al.setMstatus(rs.getString("mstatus"));

				list.add(al);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(ps);
		}


		return list;
	}

    public int getReportListCount(Connection con) {
		int result = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;

		String sql = prop.getProperty("reportListCount");

		try {
			ps = con.prepareStatement(sql);

			rs = ps.executeQuery();

			if(rs.next()){
				result = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(ps);

		}
		return result;
	}

	public ArrayList<RpList> reportSelectList(Connection con, int currentPage, int limit) {
		ArrayList<RpList> list = new ArrayList<>();
		PreparedStatement ps = null;
		ResultSet rs = null;

		String sql = prop.getProperty("reportSelectList");

		try {
			ps = con.prepareStatement(sql);

			int startRow = (currentPage - 1) * limit + 1;
			int endRow = startRow + limit -1;

			ps.setInt(1, endRow);
			ps.setInt(2, startRow);

			rs = ps.executeQuery();

			while(rs.next()) {
				RpList rl = new RpList();
				rl.setMno(rs.getInt("mno"));
				rl.setGradeno(rs.getInt("gradeno"));
				rl.setMuserid(rs.getString("muserid"));
				rl.setMname(rs.getString("mname"));
				rl.setMemail(rs.getString("memail"));
				rl.setMnickname(rs.getString("mnickname"));
				rl.setMjoin(rs.getDate("mjoin"));
				rl.setMrevice(rs.getDate("mrevice"));
				rl.setMdelete(rs.getDate("mdelete"));
				rl.setMreport(rs.getInt("mreport"));
				rl.setMstatus(rs.getString("mstatus"));


				list.add(rl);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(ps);
		}


		return list;
	}

    public int getDeleteListCount(Connection con) {

		int result = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;

		String sql = prop.getProperty("deleteListCount");

		try {
			ps = con.prepareStatement(sql);

			rs = ps.executeQuery();

			if(rs.next()){
				result = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(ps);

		}
		return result;

    }

	public ArrayList<DeList> deleteSelectList(Connection con, int currentPage, int limit) {
		ArrayList<DeList> list = new ArrayList<>();
		PreparedStatement ps = null;
		ResultSet rs = null;

		String sql = prop.getProperty("deleteSelectList");

		try {
			ps = con.prepareStatement(sql);

			int startRow = (currentPage - 1) * limit + 1;
			int endRow = startRow + limit -1;

			ps.setInt(1, endRow);
			ps.setInt(2, startRow);

			rs = ps.executeQuery();

			while(rs.next()) {
				DeList dl = new DeList();
				dl.setMno(rs.getInt("mno"));
				dl.setGradeno(rs.getInt("gradeno"));
				dl.setMuserid(rs.getString("muserid"));
				dl.setMname(rs.getString("mname"));
				dl.setMemail(rs.getString("memail"));
				dl.setMnickname(rs.getString("mnickname"));
				dl.setMjoin(rs.getDate("mjoin"));
				dl.setMrevice(rs.getDate("mrevice"));
				dl.setMdelete(rs.getDate("mdelete"));
				dl.setMreport(rs.getInt("mreport"));
				dl.setMstatus(rs.getString("mstatus"));


				list.add(dl);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(rs);
			close(ps);
		}


		return list;
	}

    public int combackUser(Connection con, int mno) {
		int result = 0;
		PreparedStatement ps = null;
		String sql = prop.getProperty("combackUser");

		try {
			ps = con.prepareStatement(sql);

			ps.setInt(1, mno);

			result = ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			close(ps);

		}

		return result;
	}

}// end of class
