package com.kh.admin.model.service;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.admin.controller.AdminList;
import com.kh.admin.model.dao.UserListDAO;
import com.kh.admin.model.vo.RpList;
import com.kh.admin.model.vo.UserList;
import com.kh.admin.model.vo.AdList;
import com.kh.admin.model.vo.DeList;

import static com.kh.common.JDBCTemplate.*;

public class AdUserService {

	private Connection con;
	private UserListDAO dao = new UserListDAO();
	
	public int getListCount() {
		con = getConnection();
		
		int result = dao.getListCount(con);
		
		close(con);
		
		return result;
	}

	public ArrayList<UserList> selectList(int currentPage, int limit) {
		con = getConnection();
		ArrayList<UserList> list = dao.selectList(con, currentPage, limit);
		
		close(con);
		
		return list;
	}

	public int getAdminListCount() {
		con = getConnection();
		
		int result = dao.getAdminListCount(con);
		
		close(con);

		return result;
	}

	public ArrayList<AdList> adminSelectList(int currentPage, int limit) {
		con = getConnection();
		ArrayList<AdList> list = dao.adminSelectList(con, currentPage, limit);
		
		close(con);
		
		return list;
	}

    public int getReportListCount() {
		con = getConnection();

		int result = dao.getReportListCount(con);

		close(con);

		return result;

    }

	public ArrayList<RpList> reportSelectList(int currentPage, int limit) {
		con = getConnection();
		ArrayList<RpList> list = dao.reportSelectList(con, currentPage, limit);

		close(con);

		return list;
	}

	public int getDeleteListCount() {
		con = getConnection();

		int result = dao.getDeleteListCount(con);

		close(con);

		return result;
	}

	public ArrayList<DeList> deleteSelectList(int currentPage, int limit) {
		con = getConnection();
		ArrayList<DeList> list = dao.deleteSelectList(con, currentPage, limit);

		close(con);

		return list;
	}

	public int combackUser(int mno) {
		con = getConnection();

		int result = dao.combackUser(con, mno);

		if (result > 0) {
			commit(con);
		} else {
			rollback(con);
		}

		return result;
	}


}
