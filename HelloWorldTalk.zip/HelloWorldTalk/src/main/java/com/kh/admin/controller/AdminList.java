package com.kh.admin.controller;

import com.kh.admin.model.service.AdUserService;
import com.kh.admin.model.vo.AdList;
import com.kh.admin.model.vo.PageInfoFad;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Servlet implementation class AdminList
 */
@WebServlet("/adminList.ad")
public class AdminList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<AdList> list = new ArrayList<>();
		AdUserService service = new AdUserService();
		
		//Paging 처리
		int startPage;
		int endPage;
		int maxPage;
		int currentPage = 1;
		int limit = 10;
		
		if(request.getParameter("currentPage") != null) {
			currentPage = Integer.parseInt(request.getParameter("currentPage"));
		}
		
		int listCount = service.getAdminListCount();

		
		maxPage = (int)((double)listCount/limit +0.9);
		startPage = (int)(((double)currentPage/limit + 0.9)-1) * limit +1;
		endPage = startPage + limit -1;
		
		if(maxPage < endPage) {
			endPage = maxPage;
		}
		
		list = service.adminSelectList(currentPage, limit);
		

			
			PageInfoFad pi = new PageInfoFad(currentPage, listCount, limit, maxPage, startPage, endPage);

			
			request.setAttribute("list", list);
			request.setAttribute("pi", pi);
			
			RequestDispatcher view = request.getRequestDispatcher("/views/admin/userAdmin.jsp");
			view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
