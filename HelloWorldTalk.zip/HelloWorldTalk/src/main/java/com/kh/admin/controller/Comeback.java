package com.kh.admin.controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

import com.kh.admin.model.service.AdUserService;
import com.kh.admin.model.vo.*;

@WebServlet("/comeBack.ad")
public class Comeback extends HttpServlet {

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int mno = Integer.parseInt(request.getParameter("mno"));
        int result = 0;

        //System.out.println("mno : " + mno ); 서블릿 전달 ok

        result = new AdUserService().combackUser(mno);

        System.out.println("result : " + result);

        if (result > 0) {

            response.sendRedirect(request.getContextPath() + "/deleteList.ad");
        }
    }
}