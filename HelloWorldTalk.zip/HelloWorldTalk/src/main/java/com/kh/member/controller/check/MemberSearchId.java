package com.kh.member.controller.check;


import com.kh.member.model.service.MemberService;
import com.kh.member.model.vo.Member;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


/**

 * Servlet implementation class MemberSearchId

 */

@WebServlet("/searchId.do")

public class MemberSearchId extends HttpServlet {

    private static final long serialVersionUID = 1L;


    /**

     * @see HttpServlet#HttpServlet()

     */

    public MemberSearchId() {

        super();

// TODO Auto-generated constructor stub

    }


    /**

     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)

     */

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws  IOException {

// 1. 인코딩

        request.setCharacterEncoding("UTF-8");



        String userName = request.getParameter("userName");

        String email = request.getParameter("email");



        System.out.println("서블릿 전달 확인 : " + userName + "/" + email);



        Member IdCheck = new Member();


        MemberService service = new MemberService();

        IdCheck = service.findId(IdCheck.findId(email, userName));



        System.out.println("받아온 정보 확인 : " + IdCheck);


        String s = IdCheck.getmUserId();


        if(IdCheck != null) {


            response.getWriter().print(s);



        }



    }


    /**

     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)

     */

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws  IOException {

// TODO Auto-generated method stub

        doGet(request, response);

    }


}
