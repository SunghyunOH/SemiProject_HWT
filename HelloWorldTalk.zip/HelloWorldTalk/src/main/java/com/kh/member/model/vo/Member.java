package com.kh.member.model.vo;

import java.io.Serializable;
import java.sql.Date;
import java.time.LocalDateTime;

public class Member implements Serializable {

    private static final long serialVersionUID = 1002L;

    private Long mNo;
    private int mGradeno;
    private String mUserId;
    private String mUserPwd;
    private String mEmail;
    private String mName;
    private String mNick;
    private Date mJoin;
    private Date mrevice;
    private Date mDelete;
    private int mReport;
    private String mStatus;

    private SkillStack skillStack;
    private UserSkill userSkill;
    private Profile mProFile;


    public Profile getProfile() {
        return mProFile;
    }

    public void setProfile(Profile profile) {
        this.mProFile = profile;
    }

    public SkillStack getSkillStack() {
        return skillStack;
    }


    public void setSkillStack(SkillStack skillStack) {
        this.skillStack = skillStack;
    }


    public UserSkill getUserSkill() {
        return userSkill;
    }


    public void setUserSkill(UserSkill userSkill) {
        this.userSkill = userSkill;
    }


    public Member() {
        super();
        // TODO Auto-generated constructor stub
    }


    public Member(String mUserId, String mUserPwd) {
        super();
        this.mUserId = mUserId;
        this.mUserPwd = mUserPwd;
    }


    public Member(int mGradeno, String mUserId, String mUserPwd, String mName, String mEmail, String mNick,
                  Date mrevice, Date mDelete, Profile mProFile, int mReport, String mStatus) {
        super();
        this.mGradeno = mGradeno;
        this.mUserId = mUserId;
        this.mUserPwd = mUserPwd;
        this.mName = mName;
        this.mEmail = mEmail;
        this.mNick = mNick;
        this.mrevice = mrevice;
        this.mDelete = mDelete;
        this.mProFile = mProFile;
        this.mReport = mReport;
        this.mStatus = mStatus;
    }

    public Member findId(String mEmail, String mName) {

        this.mEmail = mEmail;

        this.mName = mName;

        return this;

    }


    public Member findPwd(String mEmail, String mUserId) {

        this.mEmail = mEmail;

        this.mUserId = mUserId;

        return this;

    }


    public Long getmNo() {
        return mNo;
    }


    public void setmNo(Long mNo) {
        this.mNo = mNo;
    }


    public int getmGradeno() {
        return mGradeno;
    }


    public void setmGradeno(int mGradeno) {
        this.mGradeno = mGradeno;
    }


    public String getmUserId() {
        return mUserId;
    }


    public void setmUserId(String mUserId) {
        this.mUserId = mUserId;
    }


    public String getmUserPwd() {
        return mUserPwd;
    }


    public void setmUserPwd(String mUserPwd) {
        this.mUserPwd = mUserPwd;
    }


    public String getmEmail() {
        return mEmail;
    }


    public void setmEmail(String mEmail) {
        this.mEmail = mEmail;
    }


    public String getmName() {
        return mName;
    }


    public void setmName(String mName) {
        this.mName = mName;
    }


    public String getmNick() {
        return mNick;
    }


    public void setmNick(String mNick) {
        this.mNick = mNick;
    }


    public Date getmJoin() {
        return mJoin;
    }


    public void setmJoin(Date mJoin) {
        this.mJoin = mJoin;
    }


    public Date getMrevice() {
        return mrevice;
    }


    public void setMrevice(Date mrevice) {
        this.mrevice = mrevice;
    }


    public Date getmDelete() {
        return mDelete;
    }


    public void setmDelete(Date mDelete) {
        this.mDelete = mDelete;
    }


    public Profile getmProFile() {
        return mProFile;
    }


    public void setmProFile(Profile mProFile) {
        this.mProFile = mProFile;
    }


    public int getmReport() {
        return mReport;
    }


    public void setmReport(int mReport) {
        this.mReport = mReport;
    }

    public String getmStatus() {
        return mStatus;
    }

    public void setmStatus(String mStatus) {
        this.mStatus = mStatus;
    }

    @Override
    public String toString() {
        return "Member{" +
                "mNo=" + mNo +
                ", mGradeno=" + mGradeno +
                ", mUserId='" + mUserId + '\'' +
                ", mUserPwd='" + mUserPwd + '\'' +
                ", mEmail='" + mEmail + '\'' +
                ", mName='" + mName + '\'' +
                ", mNick='" + mNick + '\'' +
                ", mJoin=" + mJoin +
                ", mrevice=" + mrevice +
                ", mDelete=" + mDelete +
                ", mReport=" + mReport +
                ", mStatus='" + mStatus + '\'' +
                '}';
    }
}


