package com.kh.member.controller.check;

import com.kh.member.model.service.MemberService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/nickCheck.do")
public class MemberNickCheck extends HttpServlet {

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String userNick = request.getParameter("userNick");

        MemberService service = new MemberService();

        int result = service.nickCheck(userNick);

        System.out.println("닉네임 result = " + result);


        response.getWriter().print(result);

    }
}
