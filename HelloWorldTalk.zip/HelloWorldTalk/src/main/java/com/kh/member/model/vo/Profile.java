package com.kh.member.model.vo;

import java.io.Serializable;

public class Profile implements Serializable{
	private static final long serialVersionUID = 1006L;
	
	private Member mNo;
	private String oName;
	private String cName;
	private String status;
	
	public Profile() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Profile(Member mNo, String oName, String cName, String status) {
		super();
		this.mNo = mNo;
		this.oName = oName;
		this.cName = cName;
		this.status = status;

	}

	public Member getmNo() {
		return mNo;
	}

	public void setmNo(Member mNo) {
		this.mNo = mNo;
	}

	public String getoName() {
		return oName;
	}

	public void setoName(String oName) {
		this.oName = oName;
	}

	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
