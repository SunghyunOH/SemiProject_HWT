package com.kh.member.model.dao;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

import static com.kh.common.JDBCTemplate.*;
import static com.kh.common.JDBCTemplate.close;

import com.kh.member.model.vo.Member;
import com.kh.member.model.vo.SkillStack;
import com.kh.member.model.vo.UserSkill;


public class MemberDAO {

    private Properties prop;

    public MemberDAO() {
        prop = new Properties();

        // 파일 불러오기
        // 1) 파일 경로 가져오기
        String filePath = MemberDAO.class
                .getResource("/config/member-sql.properties")
                .getPath();

        // 2) 파일 불러오기(load)
        try {
            prop.load(new FileReader(filePath));

        } catch (FileNotFoundException e) {

            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    public int insertMember(Connection con, Member m) {
        int result = 0;
        PreparedStatement ps = null;
        String sql = prop.getProperty("insertMember");

        try {

            ps = con.prepareStatement(sql);

            // 데이터베이스 숫자 시작은 1부터
            ps.setInt(1, m.getmGradeno());
            ps.setString(2, m.getmUserId());
            ps.setString(3, m.getmUserPwd());
            ps.setString(4, m.getmEmail());
            ps.setString(5, m.getmName());
            ps.setString(   6, m.getmNick());
            ps.setDate(7, m.getMrevice());
            ps.setDate(8, m.getmDelete());
            ps.setInt(9, m.getmReport());
            ps.setString(10, m.getmStatus());

            result = ps.executeUpdate();

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            close(ps);
        }

        return result;
    }


    public int insertUserSkill(Connection con, UserSkill us) {
        int result = 0;
        PreparedStatement ps = null;
        String sql3 = prop.getProperty("insertMember2");
        try {
            ps = con.prepareStatement(sql3);

            String[] split = us.gettNo().split(", ");

            int i=0;

            for(i=0; i<split.length; i++){
                ps.setString(1, split[i]);
                ps.setInt(2, us.gettCh());
                ps.executeUpdate();
            }

            result = i;

        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            close(ps);
        }
        return result;
    }

    public int updateUserSkill(Connection con, UserSkill us, Member m) {
        int result = 0;
        PreparedStatement ps = null;
        String sql3 = prop.getProperty("updateSkill");
        try {
            ps = con.prepareStatement(sql3);

            String[] split = us.gettNo().split(", ");



            int i=0;

            for(i=0; i<split.length; i++){
                ps.setString(2, split[i]);
                ps.setInt(3, us.gettCh());
                ps.setLong(1, m.getmNo());
                ps.executeUpdate();
            }

            result = i;

        }catch (SQLException e){
            e.printStackTrace();
        }finally {
            close(ps);
        }
        return result;
    }




    public Member selectMember(Connection con, Member m) {
        Member result = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        String sql = prop.getProperty("selectMember");

        try {
            // 2. ps 에 준비한 쿼리 연결
            ps = con.prepareStatement(sql);

            // 3. sql ? 채우기
            ps.setString(1, m.getmUserId());
            ps.setString(2, m.getmUserPwd());

            // 4. rs (select 실행 결과) 받아오기
            rs = ps.executeQuery();

            if(rs.next()) {
                result = new Member();

                result.setmNo(rs.getLong("mno"));
                result.setmGradeno(rs.getInt("gradeno"));
                result.setmUserId(   rs.getString("muserid") );
                result.setmUserPwd(  rs.getString("muserpwd"));
                result.setmName( rs.getString("mname"));
                result.setmEmail(    rs.getString("memail")  );
                result.setmNick(rs.getString("mnickname"));
                result.setmJoin(rs.getDate("mjoin"));
                result.setMrevice(rs.getDate("mrevice"));
                result.setmDelete(rs.getDate("mdelete"));
                result.setmReport(rs.getInt("mreport"));
                result.setmStatus(rs.getString("mstatus"));


            }

            System.out.println("조회 결과 : " + result);

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            close(rs);
            close(ps);
        }

        return result;
    }



    public int updateMember(Connection con, Member m) {
        int result = 0;
        PreparedStatement ps = null;
        String sql = prop.getProperty("updateMember");

        try {

            ps = con.prepareStatement(sql);

            ps.setString(1, m.getmUserPwd());
            ps.setString(2, m.getmName());
            ps.setString(3, m.getmEmail());
            ps.setString(   4, m.getmNick());
            ps.setDate(5, m.getMrevice());
            ps.setLong(6,m.getmNo());

            result = ps.executeUpdate();

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {

            close(ps);
        }

        return result;
    }

    public void clearSkill(Connection con, Member m) {


        PreparedStatement ps = null;
        String sql = prop.getProperty("clearSkill");

        try {

            ps = con.prepareStatement(sql);


            ps.setLong(1, m.getmNo());

            ps.executeUpdate();

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {

            close(ps);
        }
    }

    public UserSkill selectSkill(Connection con, Member loginMember, UserSkill us1) {
        UserSkill result = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = prop.getProperty("selectSkill");

        try {
            // 2. ps 에 준비한 쿼리 연결
            ps = con.prepareStatement(sql);

            // 3. sql ? 채우기
            ps.setLong(1, loginMember.getmNo());
            ps.setString(2, "1");
            ps.setInt(3, 1);


            // 4. rs (select 실행 결과) 받아오기
            rs = ps.executeQuery();

            if(rs.next()) {
                result = new UserSkill();
                result.setmNo(rs.getLong("mno"));
                result.settNo(rs.getString("tno"));
                result.settCh(rs.getInt("tch"));
            }

            System.out.println("조회 결과 : " + result);

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            close(rs);
            close(ps);
        }

        return result;
    }

    public int idcheck(Connection con, String userId) {
        int result = 0;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = prop.getProperty("idcheck");

        try {
            ps = con.prepareStatement(sql);

            ps.setString(1, userId);

            rs = ps.executeQuery();

            if(rs.next()) {
                result = rs.getInt(1);

            }

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            close(rs);
            close(ps);
        }

        return result;
    }

    public int nickCheck(Connection con, String userNick) {
        int result = 0;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = prop.getProperty("nickCheck");

        try {
            ps = con.prepareStatement(sql);

            ps.setString(1, userNick);

            rs = ps.executeQuery();

            if(rs.next()) {
                result = rs.getInt(1);
            }
        } catch (SQLException e) {

            e.printStackTrace();
        } finally {
            close(rs);
            close(ps);
        }

        return result;

    }

    public Member findId(Connection con, Member idCheck) {

        Member result = null;


        PreparedStatement ps = null;

        String sql = prop.getProperty("findId");

        ResultSet rs = null;


        try {

            ps = con.prepareStatement(sql);


            ps.setString(1, idCheck.getmName());

            ps.setString(2, idCheck.getmEmail());


            rs = ps.executeQuery();


            if(rs.next()) {

                result = new Member();


                result.setmUserId(rs.getString("muserid"));

            }


            System.out.println("조회 결과 : " + result);


        } catch (SQLException e) {


            e.printStackTrace();

        } finally {


            close(rs);

            close(ps);


        }

        return result;

    }


    public Member findPwd(Connection con, Member pwdCheck) {

        Member result = null;


        PreparedStatement ps = null;

        String sql = prop.getProperty("findPwd");

        ResultSet rs = null;


        try {

            ps = con.prepareStatement(sql);


            ps.setString(1, pwdCheck.getmUserId());

            ps.setString(2, pwdCheck.getmEmail());


            rs = ps.executeQuery();


            if(rs.next()) {

                result = new Member();


                result.setmUserPwd(rs.getString("muserpwd"));

            }


            System.out.println("조회 결과 : " + result);


        } catch (SQLException e) {


            e.printStackTrace();

        } finally {


            close(rs);

            close(ps);

        }


        return result;

    }

    public int deleteMember(Connection con, Member m) {

        int result = 0;

        PreparedStatement ps = null;
        String sql = prop.getProperty("deleteMember");

        try {

            ps = con.prepareStatement(sql);

            ps.setLong(1, m.getmNo());

            result  = ps.executeUpdate();

        } catch (SQLException e) {

            e.printStackTrace();
        } finally {

            close(ps);
        }


        return result;
    }
}
