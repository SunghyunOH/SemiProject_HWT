package com.kh.member.model.vo;

import java.io.Serializable;

public class SkillStack implements Serializable{
	
	private static final long serialVersionUID = 1003L;
	
	private int tNo;
	private String tName;
	
	public SkillStack() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SkillStack(int tNo, String tName) {
		super();
		this.tNo = tNo;
		this.tName = tName;
	}

	public int gettNo() {
		return tNo;
	}

	public void settNo(int tNo) {
		this.tNo = tNo;
	}

	public String gettName() {
		return tName;
	}

	public void settName(String tName) {
		this.tName = tName;
	}

	
	
	
}
