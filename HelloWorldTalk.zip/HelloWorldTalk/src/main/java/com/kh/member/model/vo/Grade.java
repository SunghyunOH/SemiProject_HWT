package com.kh.member.model.vo;

import java.io.Serializable;

public class Grade implements Serializable{
	private static final long serialVersionUID = 1005L;

	private int gradeNo;
	private String gradeName;
	
	public Grade() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Grade(int gradeNo, String gradeName) {
		super();
		this.gradeNo = gradeNo;
		this.gradeName = gradeName;
	}

	public int getGradeNo() {
		return gradeNo;
	}

	public void setGradeNo(int gradeNo) {
		this.gradeNo = gradeNo;
	}

	public String getGradeName() {
		return gradeName;
	}

	public void setGradeName(String gradeName) {
		this.gradeName = gradeName;
	}
	
	
	
}
