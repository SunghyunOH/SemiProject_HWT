package com.kh.member.model.service;


import java.sql.Connection;

import com.kh.member.model.dao.MemberDAO;
import com.kh.member.model.vo.Member;
import com.kh.member.model.vo.SkillStack;
import com.kh.member.model.vo.UserSkill;

import static com.kh.common.JDBCTemplate.*;


public class MemberService {

    private Connection con;
    private MemberDAO dao = new MemberDAO();

    public int insertMember(Member m, UserSkill us1, UserSkill us2) {
        con = getConnection();

        int result = dao.insertMember(con, m);
        dao.insertUserSkill(con, us1);
        dao.insertUserSkill(con, us2);

        if (result > 0) {
            commit(con);
        }else {
            rollback(con);
        }
        close(con);
        return result;
    }

    public Member selectMember(Member m) {
        con = getConnection();

        Member result = dao.selectMember(con, m);

        close(con);

        return result;
    }

    public int updateMember(Member m, UserSkill us1, UserSkill us2) {


        con = getConnection();

        int result = dao.updateMember(con, m);
        dao.clearSkill(con,m);
        dao.updateUserSkill(con, us1, m);
        dao.updateUserSkill(con, us2, m);

        if( result > 0 ) {
            commit(con);
        } else {
            rollback(con);
        }

        close(con);

        return result;
    }

    public Member findId(Member idCheck) {

        con = getConnection();


        Member result = dao.findId(con, idCheck);


        close(con);


        return result;

    }


    public Member findPwd(Member pwdCheck) {

        con = getConnection();


        Member result = dao.findPwd(con, pwdCheck);


        close(con);


        return result;

    }


    public UserSkill selectSkill(UserSkill us1, Member loginMember) {
        con = getConnection();

        UserSkill result = dao.selectSkill(con, loginMember, us1);


        close(con);

        return result;

    }

    public int idcheck(String userId) {

        con = getConnection();

        int result = dao.idcheck(con, userId);

        close(con);

        return result;
    }

    public int nickCheck(String userNick) {

        con = getConnection();

        int result = dao.nickCheck(con, userNick);

        close(con);

        return result;
    }

    public int deleteMember(Member m) {

        con = getConnection();

        int result = dao.deleteMember(con, m);

        if( result > 0 ) {
            commit(con);
        } else {
            rollback(con);
        }

        close(con);

        return result;
    }
}
