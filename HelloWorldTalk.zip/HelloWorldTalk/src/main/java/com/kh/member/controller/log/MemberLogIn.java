package com.kh.member.controller.log;

import com.kh.member.model.service.MemberService;
import com.kh.member.model.vo.Member;
import com.kh.member.model.vo.UserSkill;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Objects;

@WebServlet("/login.do")
public class MemberLogIn extends HttpServlet {

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String userId = request.getParameter("userId");
        String userPwd = request.getParameter("userPwd");

        // 여기까지 문제 없음!
        System.out.println("서블릿 전달 확인 : " + userId + "/" + userPwd);

        Member loginMember = new Member(userId, userPwd);


        MemberService service = new MemberService();


        loginMember = service.selectMember(loginMember);


        System.out.println("받아온 회원 정보 확인 : " + loginMember);


        if (loginMember != null) {
            // 로그인 성공!

            HttpSession session = request.getSession(true);

            session.setAttribute("member", loginMember);
            if (Objects.equals(loginMember.getmStatus(), "N")) {
                response.getWriter().print(3); //탈퇴 회원
                session.invalidate();
            } else if (loginMember.getmGradeno() != 1) {
                response.getWriter().print(1);   // 일반 회원
            } else {
                response.getWriter().print(2); // 관리자 회원
            }
        } else {
            // 로그인 실패!

            response.getWriter().print(0);
        }
    }
}
