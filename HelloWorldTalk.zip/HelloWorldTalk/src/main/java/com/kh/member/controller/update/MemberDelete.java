package com.kh.member.controller.update;

import com.kh.member.model.service.MemberService;
import com.kh.member.model.vo.Member;
import com.kh.member.model.vo.UserSkill;

import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpSession;

@WebServlet("/delete.do")
public class MemberDelete extends HttpServlet {

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");



        HttpSession session = request.getSession(false);

        Member m = (Member) session.getAttribute("member");


        MemberService service = new MemberService();

        int result = service.deleteMember(m);

        if (result > 0) {
            session.invalidate();

            response.sendRedirect("index.jsp");

        } else {
            // 정보 수정 실패!
            response.getWriter().print(0);
        }
    }
}


