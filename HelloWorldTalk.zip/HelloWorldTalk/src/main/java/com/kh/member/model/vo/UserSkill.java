package com.kh.member.model.vo;

import java.io.Serializable;
import java.sql.Array;

public class UserSkill implements Serializable{
	
	private static final long serialVersionUID = 1004L;
	
	private Long mNo;
	private String tNo;
	private int tCh;
	
	public UserSkill() {
		super();
	}
	public UserSkill(String tNo, int tCh) {
		super();

		this.tNo = tNo;
		this.tCh = tCh;
	}

	public int gettCh() {
		return tCh;
	}

	public void settCh(int tCh) {
		this.tCh = tCh;
	}

	public Long getmNo() {
		return mNo;
	}
	public void setmNo(Long mNo) {
		this.mNo = mNo;
	}
	public String gettNo() {
		return tNo;
	}
	public void settNo(String tNo) {
		this.tNo = tNo;
	}

	@Override
	public String toString() {
		return "UserSkill{" +
				"mNo=" + mNo +
				", tNo='" + tNo + '\'' +
				", tCh=" + tCh +
				'}';
	}
}
