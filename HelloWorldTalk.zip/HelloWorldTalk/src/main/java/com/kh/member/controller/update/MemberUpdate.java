package com.kh.member.controller.update;

import com.kh.member.model.service.MemberService;
import com.kh.member.model.vo.Member;
import com.kh.member.model.vo.UserSkill;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;


@WebServlet("/update.do")
public class MemberUpdate extends HttpServlet {

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String userId = request.getParameter("userId");
        String userPwd = request.getParameter("userPwd");
        String userEmail = request.getParameter("email");
        String userName = request.getParameter("userName");
        String userNick = request.getParameter("userNick");
        String skill1 = String.join(", ", request.getParameterValues("skill"));
        String skill2 = String.join(", ", request.getParameterValues("skill2"));



        HttpSession session = request.getSession(false);

        Member m = (Member)session.getAttribute("member");

        UserSkill us1 = new UserSkill(skill1,1);
        UserSkill us2 = new UserSkill(skill2,2);

        m.setmUserId(userId);
        m.setmUserPwd(userPwd);
        m.setmEmail(userEmail);
        m.setmName(userName);
        m.setmNick(userNick);
        us1.settNo(skill1);
        us2.settNo(skill2);



        System.out.println("변경한 회원 정보 확인 : " + m);

        MemberService service = new MemberService();

        int result = service.updateMember(m,us1, us2);


        if(result > 0) {
            session.invalidate();

            response.sendRedirect("index.jsp");

        } else {
            // 정보 수정 실패!
            response.getWriter().print(0);
        }



         /*else {

            RequestDispatcher view
                    = request.getRequestDispatcher("views/common/errorPage.jsp");

            request.setAttribute("error-msg", "회원 정보 수정 실패");

            view.forward(request, response);
        }*/
    }
}