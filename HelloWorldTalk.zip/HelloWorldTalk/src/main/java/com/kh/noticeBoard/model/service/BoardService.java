package com.kh.noticeBoard.model.service;

import static com.kh.common.JDBCTemplate.*;


import java.sql.Connection;
import java.util.ArrayList;

import com.kh.member.model.vo.Member;
import com.kh.noticeBoard.model.dao.BoardDAO;
import com.kh.noticeBoard.model.vo.noticeBoard;



public class BoardService {
	private Connection con;
	private BoardDAO dao = new BoardDAO();

	public int getListCount() {
		con = getConnection();

		int result = dao.getListCount(con);

		close(con);

		return result;
	}

	public ArrayList<noticeBoard> selectList(int currentPage, int limit) {
		con = getConnection();
		ArrayList<noticeBoard> list = dao.selectList(con, currentPage, limit);

		close(con);

		return list;
	}

	public noticeBoard selectOne(int nbno) {
		con = getConnection();
		
		noticeBoard b = dao.selectOne(con, nbno);
		if( b != null ) {
			// 조회수 1 증가
			b.setNcount( b.getNcount() + 1);

			int result = dao.updateReadCount(con, nbno);

			if(result > 0) {
				commit(con);
			} else {
				rollback(con);
			}
		}

		close(con);

		return b;
	}

	public int insertNotice(noticeBoard b, Member m) {
		
		con = getConnection();
		
		int result = dao.insertNotice(con, b,m);
		
		if( result > 0) {
			commit(con);
		} else {
			rollback(con);
		}
		
		close(con);

		return result;
	}

	public noticeBoard updateView(int nbno) {
		con = getConnection();
		
		noticeBoard b = dao.selectOne(con, nbno);
		
		close(con);
		
		return b;
	}

	public int updateBoard(noticeBoard b, Member m) {
		con = getConnection();
		int result = dao.updateBoard(con, b, m);
		
		if( result > 0 ) {
			commit(con);
		} else {
			rollback(con);
		}
		
		close(con);
		
		return result;
	}

	public int deleteNotice(int nbno) {
		con = getConnection();
		int result = dao.deleteNotice(con, nbno); 
		
		if( result > 0) {
			commit(con); 
		}else {
			rollback(con);
		}
		
		close(con);

		return result;
	}
	
	

}
