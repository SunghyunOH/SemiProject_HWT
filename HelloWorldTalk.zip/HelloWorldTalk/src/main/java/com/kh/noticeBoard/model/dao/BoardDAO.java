package com.kh.noticeBoard.model.dao;


import static com.kh.common.JDBCTemplate.*;
import static com.kh.common.JDBCTemplate.close;


import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.member.model.vo.Member;
import com.kh.noticeBoard.model.vo.noticeBoard;




public class BoardDAO {
	
	private Properties prop;
	
	public BoardDAO() {
		prop = new Properties();
		String filePath = BoardDAO.class
				          .getResource("/config/noticeboard-sql.properties").getPath();
		
		try {
			prop.load(new FileReader(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int getListCount(Connection con) {
		int result = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("noticelistCount");
		
		try {
			ps = con.prepareStatement(sql);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				result = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			close(rs);
			close(ps);
		}
		
		return result;
	}

	public ArrayList<noticeBoard> selectList(Connection con, int currentPage, int limit) {
		ArrayList<noticeBoard> list = new ArrayList<>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("noticeselectList");
		
		try {
			ps = con.prepareStatement(sql);
			
			int startRow = (currentPage - 1) * limit + 1;
			int endRow = startRow + limit - 1;
			
			ps.setInt(1, endRow);
			ps.setInt(2, startRow);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				noticeBoard b = new noticeBoard();
				
				b.setNbNo(rs.getInt("nbNo"));
				b.setNbTitle(rs.getString("nbTitle"));
				b.setNbContent(rs.getString("nbContent"));
				b.setBdate(rs.getDate("nbdate"));
				b.setStatus(rs.getString("status"));
				b.setNcount(rs.getInt("NBCOUNT"));
				b.setNwriter(rs.getString("NWRITER"));
				
				list.add(b);
				
			}		
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			close(rs);
			close(ps);
		}
		
		return list;
	}

	public noticeBoard selectOne(Connection con, int nbno) {
		noticeBoard b = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("noticeSelectOne");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setInt(1, nbno);
			
			rs = ps.executeQuery();
			

			
			if( rs.next() ) {
				b = new noticeBoard();
				
				b.setNbNo(rs.getInt("nbNo"));
				b.setNbTitle(rs.getString("nbTitle"));
				b.setNbContent(rs.getString("nbContent"));
				b.setBdate(rs.getDate("nbdate"));
				b.setStatus(rs.getString("status"));
				b.setNcount(rs.getInt("NBCOUNT"));
				b.setNbfile(rs.getString("NBFILE"));
				b.setNwriter(rs.getString("NWRITER"));
				
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			close(rs);
			close(ps);
		}
		
		return b;
	}

	public int insertNotice(Connection con, noticeBoard b, Member m) {
		int result = 0;
		PreparedStatement ps = null;
		
		String sql = prop.getProperty("noticeInsertBoard");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setString(1, b.getNbTitle());
			ps.setString(2, b.getNbContent());
			ps.setString(3, m.getmNick());
			ps.setString(4, b.getNbfile());
			
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(ps);
		}
		
		return result;
	}

	public int updateBoard(Connection con, noticeBoard b, Member m) {
		int result = 0;
		PreparedStatement ps = null;
		
		String sql = prop.getProperty("noticeUpdateBoard");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setString(1,  b.getNbTitle() );
			ps.setString(2,  b.getNbContent() );
			ps.setString(3, b.getNbfile());
			ps.setInt(   4,  b.getNbNo() );
			
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
		}
		
		return result;
	}

	public int deleteNotice(Connection con, int nbno) {
		int result = 0;
		PreparedStatement ps = null;
		String sql = prop.getProperty("deleteNotice");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setInt(1, nbno);

			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(ps);
		}
		
		
		
		return result;
	}


	public int updateReadCount(Connection con, int nbno) {

		int result = 0;
		PreparedStatement ps = null;

		String sql = prop.getProperty("noticeUpdateReadCount");

		try {
			ps = con.prepareStatement(sql);

			ps.setInt(1, nbno);

			result = ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
		}
		return result;

	}
}
