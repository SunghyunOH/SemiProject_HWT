package com.kh.noticeBoard.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.member.model.vo.Member;
import com.kh.noticeBoard.model.service.BoardService;
import com.kh.noticeBoard.model.vo.noticeBoard;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

/**
 * Servlet implementation class BoardNoticeInsert
 */
@WebServlet("/noticeInsert.do")
public class BoardNoticeInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BoardNoticeInsert() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int maxSize = 1024 * 1024 * 10;

		String root = request.getServletContext().getRealPath("/");
		String savePath = root + "resources/boardUploadFiles";

		MultipartRequest mre = new MultipartRequest(request, savePath, maxSize, "UTF-8",
				new DefaultFileRenamePolicy());

		String title = mre.getParameter("title");
		String content = mre.getParameter("content");
		String userId = mre.getParameter("reg_id");

		String filename = mre.getFilesystemName("file");

		noticeBoard b = new noticeBoard(title, content, userId, filename);

		BoardService service = new BoardService();

		HttpSession session = request.getSession(false);

		Member m = (Member) session.getAttribute("member");

		int result = service.insertNotice(b, m);
		
		if( result > 0) {
			response.sendRedirect("/hwt/notice.do");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
