package com.kh.noticeBoard.model.vo;


import java.io.Serializable;
import java.sql.Date;

public class noticeBoard implements Serializable{

	private static final long serialVersionUID = 1008L;
	
	private int nbNo;
	private String nbTitle;
	private String nbContent;
	private Date bdate;
	private String status;
	private int ncount;
	private String nwriter;
	private String nbfile;


	public noticeBoard() {
		super();
		// TODO Auto-generated constructor stub
	}

	


	public noticeBoard(String nbTitle, String nbContent) {
		super();
		this.nbTitle = nbTitle;
		this.nbContent = nbContent;
	}

	public noticeBoard(String nbTitle, String nbContent, String nwriter, String nbfile) {
		this.nbTitle = nbTitle;
		this.nbContent = nbContent;
		this.nwriter = nwriter;
		this.nbfile = nbfile;
	}

	public int getNbNo() {
		return nbNo;
	}

	public void setNbNo(int nbNo) {
		this.nbNo = nbNo;
	}

	public String getNbTitle() {
		return nbTitle;
	}

	public void setNbTitle(String nbTitle) {
		this.nbTitle = nbTitle;
	}

	public String getNbContent() {
		return nbContent;
	}

	public void setNbContent(String nbContent) {
		this.nbContent = nbContent;
	}

	public Date getBdate() {
		return bdate;
	}

	public void setBdate(Date bdate) {
		this.bdate = bdate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getNcount() {
		return ncount;
	}

	public void setNcount(int ncount) {
		this.ncount = ncount;
	}

	public String getNwriter() {
		return nwriter;
	}

	public void setNwriter(String nwriter) {
		this.nwriter = nwriter;
	}


	public String getNbfile() {
		return nbfile;
	}

	public void setNbfile(String nbfile) {
		this.nbfile = nbfile;
	}

	@Override
	public String toString() {
		return "noticeBoard [nbNo=" + nbNo + ", nbTitle=" + nbTitle + ", nbContent=" + nbContent + ", bdate=" + bdate
				+ ", status=" + status + "]";
	}
	
	

	
}
