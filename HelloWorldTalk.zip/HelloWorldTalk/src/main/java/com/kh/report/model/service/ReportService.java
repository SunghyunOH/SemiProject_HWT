package com.kh.report.model.service;

import com.kh.report.model.dao.ReportDAO;
import com.kh.report.model.vo.Report;

import java.sql.Connection;
import java.util.ArrayList;

import static com.kh.common.JDBCTemplate.*;

public class ReportService {

    private Connection con;
    private ReportDAO dao = new ReportDAO();

    public int getReportCount() {

        con = getConnection();

        int result = dao.getReportCount(con);

        close(con);

        return result;


    }

    public ArrayList<Report> reportAdSelectList(int currentPage, int limit) {
        con = getConnection();
        ArrayList<Report> list = dao.reportadSelectList(con, currentPage, limit);

        close(con);

        return list;
    }

    public int kickUser(int mno) {
        con = getConnection();

        int result = dao.kickUser(con, mno);

        if (result > 0) {
            commit(con);
        } else {
            rollback(con);
        }

        return result;
    }

    public int alarmUser(int mno) {
        con = getConnection();

        int result = dao.alarmUser(con, mno);

        if (result > 0) {
            commit(con);
        } else {
            rollback(con);
        }

        return result;
    }
}
