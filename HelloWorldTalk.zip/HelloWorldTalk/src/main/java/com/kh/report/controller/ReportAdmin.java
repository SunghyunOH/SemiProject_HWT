package com.kh.report.controller;


import com.kh.report.model.service.ReportService;
import com.kh.report.model.vo.PageInfoFReport;
import com.kh.report.model.vo.Report;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

@WebServlet("/reportAdmin.ad")
public class ReportAdmin extends HttpServlet {
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        ArrayList<Report> list = new ArrayList<Report>();
        ReportService service = new ReportService();

        //Paging 처리
        int startPage;
        int endPage;
        int maxPage;
        int currentPage = 1;
        int limit = 10;

        if(request.getParameter("currentPage") != null) {
            currentPage = Integer.parseInt(request.getParameter("currentPage"));
        }

        int listCount = service.getReportCount();


        maxPage = (int)((double)listCount/limit +0.9);
        startPage = (int)(((double)currentPage/limit + 0.9)-1) * limit +1;
        endPage = startPage + limit -1;

        if(maxPage < endPage) {
            endPage = maxPage;
        }

        list = service.reportAdSelectList(currentPage, limit);

        PageInfoFReport pi = new PageInfoFReport(currentPage, listCount, limit, maxPage, startPage, endPage);

        request.setAttribute("list", list);
        request.setAttribute("pi", pi);

        RequestDispatcher view = request.getRequestDispatcher("/views/admin/report.jsp");
        view.forward(request, response);
    }
}
