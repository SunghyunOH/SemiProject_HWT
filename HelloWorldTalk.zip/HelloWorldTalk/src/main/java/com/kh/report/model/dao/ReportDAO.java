package com.kh.report.model.dao;

import com.kh.report.model.vo.Report;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import static com.kh.common.JDBCTemplate.close;

public class ReportDAO {
    private Properties prop;

    public ReportDAO(){
        prop = new Properties();

        String filePath = ReportDAO.class.getResource("/config/report-sql.properties").getPath();

        try {
            prop.load(new FileReader(filePath));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getReportCount(Connection con) {
        int result = 0;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = prop.getProperty("reportCount");

        try {
            ps = con.prepareStatement(sql);

            rs = ps.executeQuery();

            if(rs.next()){
                result = rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            close(rs);
            close(ps);

        }
        return result;

    }


    public ArrayList<Report> reportadSelectList(Connection con, int currentPage, int limit) {
        ArrayList<Report> list = new ArrayList<>();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String sql = prop.getProperty("reportAdSelectList");

        try {
            ps = con.prepareStatement(sql);

            int startRow = (currentPage - 1) * limit + 1;
            int endRow = startRow + limit -1;
            System.out.println(startRow);
            System.out.println(endRow);
            ps.setInt(1, endRow);
            ps.setInt(2, startRow);

            rs = ps.executeQuery();

            while(rs.next()) {
                Report rp = new Report();
                rp.setMno(rs.getInt("mno"));
                rp.setGradeno(rs.getInt("gradeno"));
                rp.setMuserid(rs.getString("muserid"));
                rp.setMname(rs.getString("mname"));
                rp.setMemail(rs.getString("memail"));
                rp.setMnickname(rs.getString("mnickname"));
                rp.setMreport(rs.getInt("mreport"));
                rp.setMstatus(rs.getString("mstatus"));

                list.add(rp);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            close(rs);
            close(ps);
        }
        return list;
    }

    public int kickUser(Connection con, int mno) {
        int result = 0;
        PreparedStatement ps = null;
        String sql = prop.getProperty("kickUser");

        try {
            ps = con.prepareStatement(sql);

            ps.setInt(1, mno);

            result = ps.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {

            close(ps);
        }

        return result;
    }

    public int alarmUser(Connection con, int mno) {
        int result = 0;
        PreparedStatement ps = null;
        ResultSet rs = null;

        String sql = prop.getProperty("alarmUser");

        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            if (rs.next()) {
                result = rs.getInt(1);
            }
            System.out.println("dao"+result);

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            close(rs);
            close(ps);

        }

        return result;
    }
}
