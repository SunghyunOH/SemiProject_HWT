package com.kh.report.model.vo;

import java.sql.Date;

public class Report {

    private static final long serialVersionUID = 11113L;

    private int mno;
    private int gradeno;
    private String muserid;
    private String muserpwd;
    private String mname;
    private String memail;
    private String mnickname;
    private Date mjoin;
    private Date mrevice;
    private Date mdelete;
    private String mprofile;
    private int mreport;
    private String mstatus;

    public Report(int mno, int gradeno, String muserid, String mname, String memail, String mnickname, int mreport, String mstatus) {
        this.mno = mno;
        this.gradeno = gradeno;
        this.muserid = muserid;
        this.mname = mname;
        this.memail = memail;
        this.mnickname = mnickname;
        this.mreport = mreport;
        this.mstatus = mstatus;
    }

    public Report(int mno, int gradeno, String muserid, String muserpwd, String mname, String memail, String mnickname, Date mjoin, Date mrevice, Date mdelete, String mprofile, int mreport, String mstatus) {
        this.mno = mno;
        this.gradeno = gradeno;
        this.muserid = muserid;
        this.muserpwd = muserpwd;
        this.mname = mname;
        this.memail = memail;
        this.mnickname = mnickname;
        this.mjoin = mjoin;
        this.mrevice = mrevice;
        this.mdelete = mdelete;
        this.mprofile = mprofile;
        this.mreport = mreport;
        this.mstatus = mstatus;
    }

    public Report() {

    }

    public int getMno() {
        return mno;
    }

    public void setMno(int mno) {
        this.mno = mno;
    }

    public int getGradeno() {
        return gradeno;
    }

    public void setGradeno(int gradeno) {
        this.gradeno = gradeno;
    }

    public String getMuserid() {
        return muserid;
    }

    public void setMuserid(String muserid) {
        this.muserid = muserid;
    }

    public String getMuserpwd() {
        return muserpwd;
    }

    public void setMuserpwd(String muserpwd) {
        this.muserpwd = muserpwd;
    }

    public String getMname() {
        return mname;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }

    public String getMemail() {
        return memail;
    }

    public void setMemail(String memail) {
        this.memail = memail;
    }

    public String getMnickname() {
        return mnickname;
    }

    public void setMnickname(String mnickname) {
        this.mnickname = mnickname;
    }

    public Date getMjoin() {
        return mjoin;
    }

    public void setMjoin(Date mjoin) {
        this.mjoin = mjoin;
    }

    public Date getMrevice() {
        return mrevice;
    }

    public void setMrevice(Date mrevice) {
        this.mrevice = mrevice;
    }

    public Date getMdelete() {
        return mdelete;
    }

    public void setMdelete(Date mdelete) {
        this.mdelete = mdelete;
    }

    public String getMprofile() {
        return mprofile;
    }

    public void setMprofile(String mprofile) {
        this.mprofile = mprofile;
    }

    public int getMreport() {
        return mreport;
    }

    public void setMreport(int mreport) {
        this.mreport = mreport;
    }

    public String getMstatus() {
        return mstatus;
    }

    public void setMstatus(String mstatus) {
        this.mstatus = mstatus;
    }

    @Override
    public String toString() {
        return "Report{" +
                "mno=" + mno +
                ", gradeno=" + gradeno +
                ", muserid='" + muserid + '\'' +
                ", muserpwd='" + muserpwd + '\'' +
                ", mname='" + mname + '\'' +
                ", memail='" + memail + '\'' +
                ", mnickname='" + mnickname + '\'' +
                ", mjoin=" + mjoin +
                ", mrevice=" + mrevice +
                ", mdelete=" + mdelete +
                ", mprofile='" + mprofile + '\'' +
                ", mreport=" + mreport +
                ", mstatus='" + mstatus + '\'' +
                '}';
    }
}
