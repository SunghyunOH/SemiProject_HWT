package com.kh.report.controller;

import com.kh.report.model.service.ReportService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/alarm.ad")
public class alarm extends HttpServlet {

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int mno = Integer.parseInt(request.getParameter("mno"));
        int result = 0;

        result = new ReportService().alarmUser(mno);


        if (result > 0) {
            request.getSession().setAttribute("mno", mno);
            response.sendRedirect(request.getContextPath() + "/reportAdmin.ad");
        }
    }
}
