package com.kh.board.model.vo;

import java.util.Date;

public class BoardFile {

    private Long bfno;
    private Board bno;
    private String status;
    private String oname;
    private String cname;
    private Date date;

    public BoardFile() {
    }

    public BoardFile(Long bfno, Board bno, String status, String oname, String cname, Date date) {
        this.bfno = bfno;
        this.bno = bno;
        this.status = status;
        this.oname = oname;
        this.cname = cname;
        this.date = date;
    }

    public Long getBfno() {
        return bfno;
    }

    public void setBfno(Long bfno) {
        this.bfno = bfno;
    }

    public Board getBno() {
        return bno;
    }

    public void setBno(Board bno) {
        this.bno = bno;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOname() {
        return oname;
    }

    public void setOname(String oname) {
        this.oname = oname;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
