package com.kh.board.model.vo;

import java.io.Serializable;
import java.sql.Date;

public class noticeBoard implements Serializable{

	private static final long serialVersionUID = 1008L;
	
	private int nbNo;
	private String nbTitle;
	private String nbContent;
	private Date bdate;
	private String status;
	
	public noticeBoard() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	



	public noticeBoard(String nbTitle, String nbContent) {
		super();
		this.nbTitle = nbTitle;
		this.nbContent = nbContent;
	}







	public noticeBoard(int nbNo, String nbTitle, String nbContent, Date bdate, String status) {
		super();
		this.nbNo = nbNo;
		this.nbTitle = nbTitle;
		this.nbContent = nbContent;
		this.bdate = bdate;
		this.status = status;
	}

	public int getNbNo() {
		return nbNo;
	}

	public void setNbNo(int nbNo) {
		this.nbNo = nbNo;
	}

	public String getNbTitle() {
		return nbTitle;
	}

	public void setNbTitle(String nbTitle) {
		this.nbTitle = nbTitle;
	}

	public String getNbContent() {
		return nbContent;
	}

	public void setNbContent(String nbContent) {
		this.nbContent = nbContent;
	}

	public Date getBdate() {
		return bdate;
	}

	public void setBdate(Date bdate) {
		this.bdate = bdate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}



	@Override
	public String toString() {
		return "noticeBoard [nbNo=" + nbNo + ", nbTitle=" + nbTitle + ", nbContent=" + nbContent + ", bdate=" + bdate
				+ ", status=" + status + "]";
	}
	
	

	
}
