package com.kh.board.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.kh.board.model.service.BoardService;
import com.kh.board.model.vo.Board;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class BoardInsert
 */
@WebServlet("/insert.bo")
public class BoardInsert extends HttpServlet {
    private static final long serialVersionUID = 1L;



    public BoardInsert() {
        super();

    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Board> list = new ArrayList<>();
        // 파일 업로드용 서블릿
        // MultipartRequest

        // 1. 전송받은 최대크기 설정하기
        // 10MB --> Byte 단위로 작성해야 함
        // 1024Byte ---> 1KB ---> 1024 KB --> 1MB
        int maxSize = 1024 * 1024 * 10; // 10MB

        // 2. multipart/form-data 형식으로 인코딩 되어 왔는지 확인
        if(! ServletFileUpload.isMultipartContent(request)) {
            //에러 페이지

            //아작스에 넘겨서 처리
        }

        // 3. 받아온 파일을 저장할 경로 설정하기
        String root = request.getServletContext().getRealPath("/");
        String savePath = root + "resources/boardUploadFiles";

        // 4. 위에서 설정한 정보를 바탕으로 MultipartRequest 생성하기
        /**
         * @param request / 속성 변경을 위한 원본 객체
         * @param savePath / 파일 저장 경로
         * @param maxSize / 저장 가능한 파일 최대크기
         * @param encoding / ex) "UTF-8"
         * @param FileRenamePolicy / 원본파일 이름을 서버에서
         *                           관리하기 편한 이름으로
         *                           바꾸는 정책
         */
        MultipartRequest mre = new MultipartRequest(request, savePath,
                maxSize, "UTF-8",
                new DefaultFileRenamePolicy());
        // ** DefaultFileRenamePolicy 는
        //    만약 폴더에 이미 있는 파일의 이름이 또 들어 올 경우
        //    해당 이름을 바꿔주는 정책
        // ex) 새 폴더 --> 새 폴더1 --> 새 폴더2 . . .

        // ---------- 설정 끄읕~! ------------ //

        // 5-1. 파일이 아닌 기본 전송값 처리
        String type = mre.getParameter("type");
        String content = mre.getParameter("content");
        Long userMno = Long.parseLong(mre.getParameter("userMno"));


        // 5-2. 파일 저장 및 정보 처리하기
        //     JSP로부터 전달받은 파일을 먼저 저장하고
        //     해당 파일의 이름을 따온다.

        String filename = mre.getFilesystemName("file");

        // 6. 전달받은 값을 서비스로 넘기기

        Board b = new Board(type, userMno, content, filename);

        HttpSession session = request.getSession(false);

        int result = new BoardService().insertBoard(b);

        list = new BoardService().selectList2(list);

        session.setAttribute("list", list);

        session.setAttribute("board",b);



        if (result > 0) {
            response.sendRedirect("/hwt/views/main/allTap.jsp");
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doPost(request, response);
    }

}
