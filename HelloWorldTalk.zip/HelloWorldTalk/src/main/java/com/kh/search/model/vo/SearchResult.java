package com.kh.search.model.vo;

import java.io.Serializable;
import java.util.Date;

public class SearchResult implements Serializable{

	private static final long serialVersionUID = 1012;
	
	private String mUserName;
	private String mUserNick;
	private int btype;
	private int bMno;
	private int bBno;
	private String bTitle;
	private Date bDate;
	private String bName;
	

	public SearchResult() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	


	public SearchResult(String mUserName, String mUserNick, int btype, int bMno, int bBno, String bTitle, Date bDate,
			String bName) {
		super();
		this.mUserName = mUserName;
		this.mUserNick = mUserNick;
		this.btype = btype;
		this.bMno = bMno;
		this.bBno = bBno;
		this.bTitle = bTitle;
		this.bDate = bDate;
		this.bName = bName;
	}






	public String getBname() {
		return bName;
	}






	public void setBname(String bname) {
		this.bName = bname;
	}






	public String getmUserName() {
		return mUserName;
	}


	public void setmUserName(String mUserName) {
		this.mUserName = mUserName;
	}


	public String getmUserNick() {
		return mUserNick;
	}


	public void setmUserNick(String mUserNick) {
		this.mUserNick = mUserNick;
	}


	public int getBtype() {
		return btype;
	}


	public void setBtype(int btype) {
		this.btype = btype;
	}


	public int getbMno() {
		return bMno;
	}


	public void setbMno(int bMno) {
		this.bMno = bMno;
	}


	public int getbBno() {
		return bBno;
	}


	public void setbBno(int bBno) {
		this.bBno = bBno;
	}


	public String getbTitle() {
		return bTitle;
	}


	public void setbTitle(String bTitle) {
		this.bTitle = bTitle;
	}


	public Date getbDate() {
		return bDate;
	}


	public void setbDate(Date bDate) {
		this.bDate = bDate;
	}

	
	
	
}
