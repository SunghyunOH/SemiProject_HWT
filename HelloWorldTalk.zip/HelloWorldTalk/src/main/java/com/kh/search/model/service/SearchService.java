package com.kh.search.model.service;

import static com.kh.common.JDBCTemplate.close;
import static com.kh.common.JDBCTemplate.getConnection;

import java.io.Serializable;
import java.sql.Connection;
import java.util.ArrayList;

import com.kh.search.model.dao.SearchDAO;
import com.kh.search.model.vo.SearchResult;

public class SearchService implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4760715662602953022L;
	
	private Connection con;
	private SearchDAO dao = new SearchDAO();
	
	
	public ArrayList<SearchResult> searchMember(String query) {
		con = getConnection();
		
		ArrayList<SearchResult> list = dao.searchMember(con, query);
		
		close(con);
		
		
		return list;
	}


	public ArrayList<SearchResult> selectList(int currentPage, int limit, String query) {
		con = getConnection();
		ArrayList<SearchResult> list = dao.selectList(con, currentPage, limit, query);
		
		close(con);
		
		return list;
	}
	
	
	


	public int getListCount(String query) {
		con = getConnection();

		int result = dao.getListCount(con, query);

		close(con);

		return result;
	
	}

}
