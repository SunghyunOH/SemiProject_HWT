package com.kh.search.model.dao;

import static com.kh.common.JDBCTemplate.close;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.noticeBoard.model.vo.noticeBoard;
import com.kh.search.model.dao.SearchDAO;
import com.kh.search.model.vo.SearchResult;

public class SearchDAO {
private Properties prop;
	
	public SearchDAO() {
		prop = new Properties();
		String filePath = SearchDAO.class
				          .getResource("/config/search-sql.properties").getPath();
		
		try {
			prop.load(new FileReader(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<SearchResult> searchMember(Connection con, String query) {
		ArrayList<SearchResult> list = new ArrayList<>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("searchTitle");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setString(1, query);

			rs = ps.executeQuery();
			
			
			
			while( rs.next() ) {
				SearchResult sr = new SearchResult();
				
				sr.setmUserName(rs.getString("mname"));
				sr.setmUserNick(rs.getString("mnickname"));
				sr.setBtype(rs.getInt("btype"));
				sr.setbMno(rs.getInt("mno"));
				sr.setbBno(rs.getInt("bno"));
				sr.setbTitle(rs.getString("btitle"));
				sr.setbDate(rs.getDate("bdate"));
				
				
				list.add(sr);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(rs);
			close(ps);
		}
		
		return list;
	}

	public int getListCount(Connection con, String query) {
		int result = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("searchlistCount");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setString(1, query);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				result = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			close(rs);
			close(ps);
		}
		
		return result;
	}

	

	public ArrayList<SearchResult> selectList(Connection con, int currentPage, int limit, String query) {
		ArrayList<SearchResult> list = new ArrayList<>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("searchResult");
		
		try {
			ps = con.prepareStatement(sql);
			
			int startRow = (currentPage - 1) * limit + 1;
			int endRow = startRow + limit - 1;
			
			ps.setString(1, query);
			ps.setInt(2, endRow);
			ps.setInt(3, startRow);
			
			rs = ps.executeQuery();
			
			while( rs.next() ) {
				SearchResult sr = new SearchResult();
				
				sr.setmUserName(rs.getString("mname"));
				sr.setmUserNick(rs.getString("mnickname"));
				sr.setbMno(rs.getInt("mno"));
				sr.setbBno(rs.getInt("bno"));
				sr.setbTitle(rs.getString("btitle"));
				sr.setbDate(rs.getDate("bdate"));
				sr.setBname(rs.getString("bname"));
				sr.setBtype(rs.getInt("btype"));
				
				list.add(sr);
				
			}		
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			close(rs);
			close(ps);
		}
		
		return list;
	}

}
