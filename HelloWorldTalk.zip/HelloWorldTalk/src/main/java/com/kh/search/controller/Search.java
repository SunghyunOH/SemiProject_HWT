package com.kh.search.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kh.search.model.vo.PageInfob;
import com.kh.search.model.service.SearchService;
import com.kh.search.model.vo.SearchResult;

/**
 * Servlet implementation class search
 */
@WebServlet("/search.sc")
public class Search extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Search() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SearchService ss = new SearchService();
		String query = request.getParameter("search");
		// ArrayList<SearchResult> list = new ArrayList<>();
		ArrayList<SearchResult> listseac = new ArrayList<>();
		
		
		System.out.println(query);
		// System.out.println(query);		
		// list = ss.searchMember(query);
		
		// System.out.println(" 리스트 사이즈 : " +list.size());
		
		
		// 1, 2, 3, 4, 5
		int startPage, endPage;

		// 55개 게시글 -> 10개 - 페이지 1 --> 6개 페이지
		int maxPage;

		// 현재 사용자가 보는 페이지
		int currentPage = 1;

		// 페이지당 게시글 수
		int limit = 10;

		// 만약 사용자가 특정 페이지 정보를 가져왔다면
		if (request.getParameter("currentPage") != null) {
			currentPage = Integer.parseInt(request.getParameter("currentPage"));
			System.out.println(currentPage);
		}
		
		
		// 총 게시글 수 조회
		int listCount = ss.getListCount(query);

		 System.out.println("총 게시글 수 : " + listCount); // ** 중간 점검 완료! 문제없음 ** //

		// 250 / 10 --> 25
		// 251 / 10 --> 25.1
		maxPage = (int) ((double) listCount / limit + 0.9);

		// 11 ~ 20
		// 1 ~ 10
		startPage = (int) (((double) currentPage / limit + 0.9) - 1) * limit + 1;

		endPage = startPage + limit - 1;

		// 만약 마지막 페이지가 endPage보다 작다면
		if (maxPage < endPage) {
			endPage = maxPage;
		}
		// ------------- 페이지 처리 끄읕! ㅎㅅㅎ ----------- //
		listseac = ss.selectList(currentPage, limit, query);
		
		
	
		String page = "";
		
		if (listseac != null && listseac.size() > 0) {
			PageInfob pi = new PageInfob(currentPage, listCount, limit, maxPage, startPage, endPage);
			
			request.setAttribute("listb", listseac);
			request.setAttribute("pib", pi);
			System.out.println("페이지의 값 갯수 : " + listseac.size());
			page = "views/main/searchTap.jsp";
			request.setAttribute("query", query);
		}
		else {
			PageInfob pi = new PageInfob(currentPage, listCount, limit, maxPage, startPage, endPage);
			request.setAttribute("listb", listseac);
			request.setAttribute("pib", pi);
			
			page = "views/main/searchTap.jsp";
			
			}

		request.getRequestDispatcher(page).forward(request, response);

	


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
