package com.kh.educationBoard.model.dao;


import com.kh.educationBoard.model.vo.educationBoard;
import com.kh.member.model.vo.Member;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import static com.kh.common.JDBCTemplate.close;


public class BoardDAO {
	
	private Properties prop;
	
	public BoardDAO() {
		prop = new Properties();
		String filePath = BoardDAO.class
				          .getResource("/config/educationBoard-sql.properties").getPath();
		
		try {
			prop.load(new FileReader(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int getEducationListCount(Connection con) {
		int result = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("educationListCount");
		
		try {
			ps = con.prepareStatement(sql);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				result = rs.getInt(1);
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			close(rs);
			close(ps);
		}
		
		return result;
	}

	public ArrayList<educationBoard> EducationSelectList(Connection con, int currentPage, int limit) {
		ArrayList<educationBoard> list = new ArrayList<>();
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("educationSelectList");
		
		try {
			ps = con.prepareStatement(sql);
			
			int startRow = (currentPage - 1) * limit + 1;
			int endRow = startRow + limit - 1;
			
			ps.setInt(1, endRow);
			ps.setInt(2, startRow);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				educationBoard b = new educationBoard();
				
				b.setEbNo(rs.getInt("EBNO"));
				b.setEbTitle(rs.getString("EBTITLE"));
				b.setEbContent(rs.getString("EBCONTENT"));
				b.setEbdate(rs.getDate("EBDATE"));
				b.setStatus(rs.getString("status"));
				b.setEcount(rs.getInt("EBCOUNT"));
				b.setEbfile(rs.getString("EBFILE"));
				b.setEbwriter(rs.getString("EWRITER"));

				list.add(b);
				
			}		
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			close(rs);
			close(ps);
		}
		
		return list;
	}

	public educationBoard EducationSelectOne(Connection con, int ebno) {
		educationBoard b = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String sql = prop.getProperty("educationSelectOne");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setInt(1, ebno);
			
			rs = ps.executeQuery();
			

			
			if( rs.next() ) {
				b = new educationBoard();
				
				b.setEbNo(rs.getInt("EBNO"));
				b.setEbTitle(rs.getString("EBTITLE"));
				b.setEbContent(rs.getString("EBCONTENT"));
				b.setEbdate(rs.getDate("EBDATE"));
				b.setStatus(rs.getString("status"));
				b.setEcount(rs.getInt("EBCOUNT"));
				b.setEbfile(rs.getString("EBFILE"));
				b.setEbwriter(rs.getString("EWRITER"));
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			close(rs);
			close(ps);
		}
		
		return b;
	}

	public int insertEducation(Connection con, educationBoard b, Member m) {
		int result = 0;
		PreparedStatement ps = null;
		
		String sql = prop.getProperty("educationInsertBoard");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setString(1, b.getEbTitle());
			ps.setString(2, b.getEbContent());
			ps.setString(3, m.getmNick());
			ps.setString(4, b.getEbfile());
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(ps);
		}
		
		return result;
	}

	public int updateEducationBoard(Connection con, educationBoard b, Member m) {
		int result = 0;
		PreparedStatement ps = null;
		
		String sql = prop.getProperty("educationUpdateBoard");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setString(1,  b.getEbTitle() );
			ps.setString(2,  b.getEbContent() );
			ps.setString(3, b.getEbfile());
			ps.setInt(   4,  b.getEbNo() );
			
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
		}
		
		return result;
	}

	public int deleteEducation(Connection con, int ebno) {
		int result = 0;
		PreparedStatement ps = null;
		String sql = prop.getProperty("deleteEducation");
		
		try {
			ps = con.prepareStatement(sql);
			
			ps.setInt(1, ebno);

			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close(ps);
		}
		
		
		
		return result;
	}


	public int educationUpdateReadCount(Connection con, int ebno) {

		int result = 0;
		PreparedStatement ps = null;

		String sql = prop.getProperty("educationUpdateReadCount");

		try {
			ps = con.prepareStatement(sql);

			ps.setInt(1, ebno);

			result = ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
		}
		return result;
	}

	public int reportPointPlus(Connection con, String nick, int ebno) {

		int result = 0;
		PreparedStatement ps = null;

		String sql = prop.getProperty("EreportPointUp");

		try {
			ps = con.prepareStatement(sql);

			ps.setString(1, nick);
			ps.setInt(2, ebno);

			result = ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close(ps);
		}
		return result;

	}

}
