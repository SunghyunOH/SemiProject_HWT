package com.kh.educationBoard.model.vo;

import java.io.Serializable;
import java.sql.Date;

public class Board implements Serializable {
	
	private static final long serialVersionUID = 1001L;
	
	private int bno;
	private int btype;
	private int mno;
	private String bcontent;
	private int bcount;
	private String bfile;
	private Date bdate;
	private String status;
	private Date brevice;
	private Date bdelete;
	private int blike;
	
	
	
	
	public Board() {
		super();
	}

	


	public Board(int bno, int btype, int mno, String bcontent, Date bdate, String status, int blike) {
		super();
		this.bno = bno;
		this.btype = btype;
		this.mno = mno;
		this.bcontent = bcontent;
		this.bdate = bdate;
		this.status = status;
		this.blike = blike;
	}




	public Board(int bno, int btype, int mno, String bcontent, int bcount, String bfile, Date bdate,
                 String status, Date brevice, Date bdelete, int blike) {
		super();
		this.bno = bno;
		this.btype = btype;
		this.mno = mno;
		this.bcontent = bcontent;
		this.bcount = bcount;
		this.bfile = bfile;
		this.bdate = bdate;
		this.status = status;
		this.brevice = brevice;
		this.bdelete = bdelete;
		this.blike = blike;
	}




	public int getBno() {
		return bno;
	}




	public void setBno(int bno) {
		this.bno = bno;
	}




	public int getBtype() {
		return btype;
	}




	public void setBtype(int btype) {
		this.btype = btype;
	}




	public int getMno() {
		return mno;
	}




	public void setMno(int mno) {
		this.mno = mno;
	}




	public String getBcontent() {
		return bcontent;
	}




	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}




	public int getBcount() {
		return bcount;
	}




	public void setBcount(int bcount) {
		this.bcount = bcount;
	}




	public String getBfile() {
		return bfile;
	}




	public void setBfile(String bfile) {
		this.bfile = bfile;
	}




	public Date getBdate() {
		return bdate;
	}




	public void setBdate(Date bdate) {
		this.bdate = bdate;
	}




	public String getStatus() {
		return status;
	}




	public void setStatus(String status) {
		this.status = status;
	}




	public Date getBrevice() {
		return brevice;
	}




	public void setBrevice(Date brevice) {
		this.brevice = brevice;
	}




	public Date getBdelete() {
		return bdelete;
	}




	public void setBdelete(Date bdelete) {
		this.bdelete = bdelete;
	}




	public int getBlike() {
		return blike;
	}




	public void setBlike(int blike) {
		this.blike = blike;
	}
	
	
	
	
	
}
