package com.kh.educationBoard.model.service;

import com.kh.educationBoard.model.dao.BoardDAO;
import com.kh.educationBoard.model.vo.educationBoard;
import com.kh.member.model.vo.Member;

import java.sql.Connection;
import java.util.ArrayList;

import static com.kh.common.JDBCTemplate.*;


public class BoardService {
	private Connection con;
	private BoardDAO dao = new BoardDAO();

	public int getEducationListCount() {
		con = getConnection();

		int result = dao.getEducationListCount(con);

		close(con);

		return result;
	}

	public ArrayList<educationBoard> EducationSelectList(int currentPage, int limit) {
		con = getConnection();
		ArrayList<educationBoard> list = dao.EducationSelectList(con, currentPage, limit);

		close(con);

		return list;
	}

	public educationBoard EducationSelectOne(int ebno) {
		con = getConnection();
		
		educationBoard b = dao.EducationSelectOne(con, ebno);

		if( b != null ) {
			// 조회수 1 증가
			b.setEcount( b.getEcount() + 1);

			int result = dao.educationUpdateReadCount(con, ebno);

			if(result > 0) {
				commit(con);
			} else {
				rollback(con);
			}
		}
		close(con);

		return b;
	}

	public int insertEducation(educationBoard b, Member m) {
		
		con = getConnection();
		
		int result = dao.insertEducation(con, b, m);
		
		if( result > 0) {
			commit(con);
		} else {
			rollback(con);
		}
		
		close(con);

		return result;
	}

	public educationBoard EducationUpdateView(int ebno) {
		con = getConnection();
		
		educationBoard b = dao.EducationSelectOne(con, ebno);
		
		close(con);
		
		return b;
	}

	public int updateEducationBoard(educationBoard b, Member m) {
		con = getConnection();
		int result = dao.updateEducationBoard(con, b, m);
		
		if( result > 0 ) {
			commit(con);
		} else {
			rollback(con);
		}
		
		close(con);
		
		return result;
	}

	public int deleteEducation(int ebno) {
		con = getConnection();
		int result = dao.deleteEducation(con, ebno);
		
		if( result > 0) {
			commit(con); 
		}else {
			rollback(con);
		}
		
		close(con);

		return result;
	}

	public int reportPointPlus(String nick, int ebno) {

		con = getConnection();
		int result = dao.reportPointPlus(con, nick, ebno);

		if( result > 0) {
			commit(con);
		}else {
			rollback(con);
		}

		close(con);
		return result;

	}
	

}
