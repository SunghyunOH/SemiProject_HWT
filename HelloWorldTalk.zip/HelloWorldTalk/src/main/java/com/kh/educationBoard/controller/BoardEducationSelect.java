package com.kh.educationBoard.controller;

import com.kh.educationBoard.model.service.BoardService;
import com.kh.educationBoard.model.vo.educationBoard;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class BoardNoticeSelecet
 */
@WebServlet("/educationSelect.do")
public class BoardEducationSelect extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public BoardEducationSelect() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int ebno = Integer.parseInt(request.getParameter("ebno"));
		BoardService service = new BoardService();


		educationBoard b = service.EducationSelectOne(ebno);
		
		String page = "";
		
		if( b != null ) {
			request.setAttribute("educationBoard", b);
			
			page = "views/education/educationBoardDetail.jsp";
		}
		request.getRequestDispatcher(page).forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
