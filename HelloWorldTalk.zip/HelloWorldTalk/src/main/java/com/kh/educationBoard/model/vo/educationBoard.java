package com.kh.educationBoard.model.vo;

import java.io.Serializable;
import java.sql.Date;

public class educationBoard implements Serializable{

	private static final long serialVersionUID = 1008L;

	private int ebNo;
	private String ebTitle;
	private String ebContent;
	private Date ebdate;
	private String status;
	private int ecount;
	private String ebwriter;
	private String ebfile;

	public educationBoard() {
		super();
		// TODO Auto-generated constructor stub
	}




	public educationBoard(String ebTitle, String ebContent) {
		super();
		this.ebTitle = ebTitle;
		this.ebContent = ebContent;
	}

	public educationBoard(String ebTitle, String ebContent, String ebwriter, String ebfile) {
		this.ebTitle = ebTitle;
		this.ebContent = ebContent;
		this.ebwriter = ebwriter;
		this.ebfile = ebfile;
	}

	public educationBoard(int ebNo, String ebTitle, String ebContent, Date ebdate, String status, int ecount) {
		this.ebNo = ebNo;
		this.ebTitle = ebTitle;
		this.ebContent = ebContent;
		this.ebdate = ebdate;
		this.status = status;
		this.ecount = ecount;
	}

	public educationBoard(int ebNo, String ebTitle, String ebContent, Date ebdate, String status, int ecount, String ebwriter, String ebfile) {
		this.ebNo = ebNo;
		this.ebTitle = ebTitle;
		this.ebContent = ebContent;
		this.ebdate = ebdate;
		this.status = status;
		this.ecount = ecount;
		this.ebwriter = ebwriter;
		this.ebfile = ebfile;
	}

	public int getEbNo() {
		return ebNo;
	}

	public void setEbNo(int ebNo) {
		this.ebNo = ebNo;
	}

	public String getEbTitle() {
		return ebTitle;
	}

	public void setEbTitle(String ebTitle) {
		this.ebTitle = ebTitle;
	}

	public String getEbContent() {
		return ebContent;
	}

	public void setEbContent(String ebContent) {
		this.ebContent = ebContent;
	}

	public Date getEbdate() {
		return ebdate;
	}

	public void setEbdate(Date ebdate) {
		this.ebdate = ebdate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getEcount() {
		return ecount;
	}

	public void setEcount(int ecount) {
		this.ecount = ecount;
	}

	public String getEbwriter() {return ebwriter;}

	public void setEbwriter(String ebwriter) {this.ebwriter = ebwriter;}

	public String getEbfile() {return ebfile;}

	public void setEbfile(String ebfile) {this.ebfile = ebfile;}

	@Override
	public String toString() {
		return "educationBoard{" +
				"ebNo=" + ebNo +
				", ebTitle='" + ebTitle + '\'' +
				", ebContent='" + ebContent + '\'' +
				", ebdate=" + ebdate +
				", status='" + status + '\'' +
				", ecount=" + ecount +
				", ebwriter='" + ebwriter + '\'' +
				", ebfile='" + ebfile + '\'' +
				'}';
	}
}
